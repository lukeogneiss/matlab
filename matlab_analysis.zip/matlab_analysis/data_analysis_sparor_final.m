%% ChatGPT Enhanced Code for SPAROR analysis

tic
clc; clear all


%% Setup file paths and import data

pname_ALL = 'D:\LTH\Digital Image Analysis 2024\session6\CT_experiments\matlab_analysis\sparor_data';
pname_images = 'D:\LTH\Digital Image Analysis 2024\session6\CT_experiments\matlab_analysis\CT_images';
pname_export = 'D:\LTH\Digital Image Analysis 2024\session6\CT_experiments\matlab_analysis\outputs';

% Create file path arrays
data_files = strcat(pname_ALL, '\sparor_results_00',string([1:8]),'.csv');
image_files = strcat(pname_images, '\CT_invert_00', string(1:8), '.tif');

% Preallocate cell arrays for data and images
AllData = cell(1, 8);
CT = cell(1, 8);

% Load data and images
for i = 1:8
    AllData{i} = readtable(data_files{i});
    CT{i} = imread(image_files{i});
    CT{i} = CT{i} / 256;
end

%% COLOUR MAPS

% load custom colormaps
CET_i1_lut = 'CET_i1.csv'; i1_lut = readmatrix(CET_i1_lut, 'Range', 'B2'); i1_lut = i1_lut / 256; % phase colormap

% or option 2 - select 8 colors from across a color map
colormap_custom = i1_lut(1:30:end, :); % activate line as needed

CET_i1_lut = 'CET_i1.csv'; i1_lut = readmatrix(CET_i1_lut, 'Range', 'B2'); i1_lut = i1_lut / 256; % phase colormap
colormap_custom = i1_lut(1:30:end, :);
%% ADD SCHMID DATA TO EVERY AllData VARIABLE

schmid_data = readtable('schmid_data.csv'); % 8x10 table

% Example source table (8x10)
sourceTable = schmid_data;

% Extract headers and data from the source table
colStartIdx = 1; % Starting column index for the headers
colEndIdx = 9; % Ending column index for the headers

% Extract the new headers and data
newHeaders = sourceTable.Properties.VariableNames(colStartIdx:colEndIdx);

% Position to insert new headers and data in the target tables
insertColPos = 20; % Insert headers starting from column 20
insertRowPos = 1; % Insert data starting from row 2

% Example cell array of tables
AllData = AllData; % 1x8 array containing 145x19 tables

% Loop through each table in the cell array
for i = 1:length(AllData)
    % Get the current table
    currentTable = AllData{i};
    
    % Determine the number of existing rows and columns in the current table
    [numRows, numCols] = size(currentTable);
    
    % Extract the new data from the corresponding row of the sourceTable
    newData = sourceTable{i, colStartIdx:colEndIdx};
    
    % Ensure the current table has enough columns to insert new data and headers at insertColPos
    if numCols < insertColPos - 1
        % Add placeholder columns to match insertColPos
        newColNum = insertColPos + length(newHeaders) - 1;
        currentTable{:, numCols+1:newColNum} = NaN;
        numCols = newColNum;
    end
    
    % Insert new headers at the specified column position
    % Create a new combined header set
    newHeaderSet = currentTable.Properties.VariableNames;
    newHeaderSet(insertColPos:insertColPos+length(newHeaders)-1) = newHeaders;
    
    % Pad remaining variable names if necessary to match number of columns
    if length(newHeaderSet) < numCols
        newHeaderSet = [newHeaderSet, strcat('Var', string(length(newHeaderSet)+1:numCols))];
    end

    % Ensure the current table has enough rows to insert new data at insertRowPos
    if numRows < insertRowPos
        % Add placeholder rows to match insertRowPos
        currentTable{numRows+1:insertRowPos, :} = NaN;
    end
    
    % Insert the new data row
    currentTable{insertRowPos, insertColPos:insertColPos+length(newData)-1} = newData;
    % Update the variable names after all modifications to the table
    currentTable.Properties.VariableNames = newHeaderSet;
    % Update the cell array with the modified table
    AllData{i} = currentTable;
end

% Display one of the updated tables to verify the result
% disp(AllData{1});

% -------

clc

%% POLAR HISTOGRAM (Tiled Layout) - Distributions

% Setup TiledLayout

t = tiledlayout(6, 8);
t.TileSpacing = 'compact';
t.Padding = 'compact'; % Adjust the padding to create more space around the tiles
t.TileIndexing = 'columnmajor';
t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% t.Parent.OuterPosition = [200, 150, 1500, 800]; % workable size
set(t, 'DefaultLineLineWidth', 1.2);

% Set figure title with additional space
titleHandle = title(t, 'Surfor & Paror Orientation Distributions - Schmid et al. 1987');
titleHandle.FontWeight = 'bold';
titleHandle.FontSize = 14;

% Adjusting the overall padding to create space for the title
t.Padding = 'tight'; % Set tight padding
t.TileSpacing = 'tight'; % Set tight tile spacing


for i = 1:8

    % Image tile
    color_CT = [0 0 0; colormap_custom(i,:)];
    nexttile
    img = image(CT{i});
    % Manually adjust the color data of the image
    img.CData = ind2rgb(img.CData, color_CT);
    axis image % Preserve aspect ratio
    axis off % Hide the axis for a cleaner image display
    title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
    % titleHandle.FontSize = 8; % Decrease font size


    % Surfor polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_surf);
    rho = AllData{i}.rho_surf;
    h = polarplot(theta, rho);
    h.Color = colormap_custom(i, :);
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Surfor Distribution');

    % Paror polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_par);
    rho = AllData{i}.rho_par;
    h = polarplot(theta, rho);
    h.Color = colormap_custom(i, :);
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Paror Distribution');

    %  Sparor Shape Function
    nexttile
    shape_x = AllData{i}.cShape_x;
    shape_y = AllData{i}.cShape_y;
    
    % Plot shape function
    h = plot(shape_x, shape_y);
    % hold on

    % Format axes and data
    h.Color = colormap_custom(i, :);
    axis equal
    axis([-1 1 -1 1])
    plax = gca; plax.XTick = -1:1:1; plax.YTick = -1:1:1;
    
    % Add title and labels
    title('Shape Function');
    % xlabel(['proj. direction [' char(176) ']'])
    % ylabel('rel. projections length')



    % Only plot the first 37 rows for projection direction and length

      % surfor projection direction plot
    nexttile
    proj_dir_s = AllData{i}.pAngle_surf(1:37);
    proj_length_s = AllData{i}.pLength_surf(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_s);
    [pks_min, locs_min] = findpeaks(-proj_length_s);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_s, proj_length_s);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_s(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_s(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = colormap_custom(i, :);
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Surfor Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
    % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------
    % Paror projection direction plot
    nexttile
    proj_dir_p = AllData{i}.pAngle_par(1:37);
    proj_length_p = AllData{i}.pLength_par(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_p);
    [pks_min, locs_min] = findpeaks(-proj_length_p);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_p, proj_length_p);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_p(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_p(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = colormap_custom(i, :);
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Paror Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
   % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end

end

% Export the final figure
% Export the final figure
fname = ['sparor_num_ordered.png'];
full_path = fullfile(pname_export, fname);
exportgraphics(gcf, full_path, 'Resolution', 1000);

%%
clc
fprintf('The first section of script finished successfully (1/2).\n')


%% REORDER AllData based upon chosen variable

% Extract the 'score' from each dataset into an array

schmid_var = 'ShearStress' % change input for ordering data
schmid_label = 'Shear Stress '; % change label for ordering variable


%set up the ordering function

% begin ordering datasets
order_var = cellfun(@(x) get_field_value(x, schmid_var), AllData);
% Get the indices of the sorted scores
[~, sortedIndices] = sort(order_var, 'ascend');
% Reorder AllData based on the sorted indices
AllData = AllData(sortedIndices);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% POLAR HISTOGRAM (Tiled Layout) - Distributions
%--------------------------------------------------------------------------
% Setup TiledLayout
%--------------------------------------------------------------------------
t = tiledlayout(6, 8);
t.TileSpacing = 'compact';
t.Padding = 'compact'; % Adjust the padding to create more space around the tiles
t.TileIndexing = 'columnmajor';
t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% t.Parent.OuterPosition = [200, 150, 1500, 800]; % workable size
set(t, 'DefaultLineLineWidth', 1.2);

% Set figure title with additional space
titleHandle = title(t, ['Surfor & Paror Orientation Distributions - ' schmid_label '(Schmid et al. 1987)']);
titleHandle.FontWeight = 'bold';
titleHandle.FontSize = 14;

% Adjusting the overall padding to create space for the title
t.Padding = 'tight'; % Set tight padding
t.TileSpacing = 'tight'; % Set tight tile spacing
 
%--------------------------------------------------------------------------
% FIGURE PLOTS 
%--------------------------------------------------------------------------
colormap_custom = i1_lut;

for i = 1:8
    
    %set up colormap
    var_row_cmap = round((AllData{i}.(schmid_var)(1,:))/max(schmid_data.(schmid_var))*256);
    color_CT = [0 0 0; colormap_custom(var_row_cmap,:)];
    color_plot = [colormap_custom(var_row_cmap,:)];
    
  % Image tile
    nexttile
    img = image(CT{i});
    % Manually adjust the color data of the image
    img.CData = ind2rgb(img.CData, color_CT);
    axis image % Preserve aspect ratio
    set(gca, 'XTick', [], 'YTick', []); % Hide the ticks
    box off; % Hide the box around the plot
    title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
    % titleHandle.FontSize = 8; % Decrease font size
% generate label for schmid_value used to order
    schmid_var_value = AllData{i}.(schmid_var)(1);
    % if schmid_var_value < 1.0e+3
    %     formatted_value = num2str(schmid_var_value, '%.1e');
    % else
    %     formatted_value = num2str(schmid_var_value);
    % end
    schmid_var_txt = [(schmid_label)  num2str(AllData{i}.(schmid_var)(1))];
    xlabel(schmid_var_txt, 'FontSize', 8);
    
   
%--------------------------------------------------------------------------
    % Surfor polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_surf);
    rho = AllData{i}.rho_surf;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Surfor Distribution');
%--------------------------------------------------------------------------
    % Paror polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_par);
    rho = AllData{i}.rho_par;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Paror Distribution');
%--------------------------------------------------------------------------
    %  Sparor Shape Function
    nexttile
    shape_x = AllData{i}.cShape_x;
    shape_y = AllData{i}.cShape_y;
    
    % Plot shape function
    h = plot(shape_x, shape_y);
    % hold on

    % Format axes and data
    h.Color = color_plot;
    axis equal
    axis([-1 1 -1 1])
    plax = gca; plax.XTick = -1:1:1; plax.YTick = -1:1:1;
    
    % Add title and labels
    title('Shape Function');
    % xlabel(['proj. direction [' char(176) ']'])
    % ylabel('rel. projections length')
   %--------------------------------------------------------------------------
     % surfor projection direction plot
    nexttile
    proj_dir_s = AllData{i}.pAngle_surf(1:37);
    proj_length_s = AllData{i}.pLength_surf(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_s);
    [pks_min, locs_min] = findpeaks(-proj_length_s);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_s, proj_length_s);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_s(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_s(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Surfor Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
    % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------
    % Paror projection direction plot
    nexttile
    proj_dir_p = AllData{i}.pAngle_par(1:37);
    proj_length_p = AllData{i}.pLength_par(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_p);
    [pks_min, locs_min] = findpeaks(-proj_length_p);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_p, proj_length_p);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_p(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_p(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Paror Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
   % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------

end 

% Create an invisible axes for the colorbar
cbaxes = axes('Position',[.98 .33 .02 .575], 'Visible', 'off'); % Adjust these values as needed
% Create the colorbar in the invisible axes
colormap(cbaxes, colormap_custom); % Apply your custom colormap to the colorbar
c = colorbar(cbaxes, 'EastOutside'); % Create the colorbar
cbaxes.CLim = [min(schmid_data.(schmid_var)) max(schmid_data.(schmid_var))];
% Position the ticks on the left side of the colorbar
c.AxisLocation = 'in'; % Position the ticks inside the colorbar
ylabel(c, (schmid_label), 'Rotation', 90); % Add a title to the colorbar


   
% Export the final figure
fname = ['sparor_' schmid_var '_ordered.png'];
full_path = fullfile(pname_export, fname);
% print(gcf, '-dpng', '-r2000', full_path);
exportgraphics(gcf, full_path, 'Resolution', 1000);
fprintf([schmid_var ' saved successfully.'])



%% REORDER AllData based upon chosen variable

% Extract the 'score' from each dataset into an array




schmid_var = 'ShearStrainRate' % change input for ordering data
schmid_label = "Shear Strain Rate "; % change label for ordering variable


%set up the ordering function

% begin ordering datasets
order_var = cellfun(@(x) get_field_value(x, schmid_var), AllData);
% Get the indices of the sorted scores
[~, sortedIndices] = sort(order_var, 'ascend');
% Reorder AllData based on the sorted indices
AllData = AllData(sortedIndices);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% POLAR HISTOGRAM (Tiled Layout) - Distributions
%--------------------------------------------------------------------------
% Setup TiledLayout
%--------------------------------------------------------------------------
t = tiledlayout(6, 8);
t.TileSpacing = 'compact';
t.Padding = 'compact'; % Adjust the padding to create more space around the tiles
t.TileIndexing = 'columnmajor';
t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% t.Parent.OuterPosition = [200, 150, 1500, 800]; % workable size
set(t, 'DefaultLineLineWidth', 1.2);

% Set figure title with additional space
titleHandle = title(t, ['Surfor & Paror Orientation Distributions - ' schmid_label '(Schmid et al. 1987)']);
titleHandle.FontWeight = 'bold';
titleHandle.FontSize = 14;

% Adjusting the overall padding to create space for the title
t.Padding = 'tight'; % Set tight padding
t.TileSpacing = 'tight'; % Set tight tile spacing

 
%--------------------------------------------------------------------------
% FIGURE PLOTS 
%--------------------------------------------------------------------------
colormap_custom = i1_lut;

for i = 1:8
    
    %set up colormap
    var_row_cmap = round((AllData{i}.(schmid_var)(1,:))/max(schmid_data.(schmid_var))*256);
    color_CT = [0 0 0; colormap_custom(var_row_cmap,:)];
    color_plot = [colormap_custom(var_row_cmap,:)];
    
  % Image tile
    nexttile
    img = image(CT{i});
    % Manually adjust the color data of the image
    img.CData = ind2rgb(img.CData, color_CT);
    axis image % Preserve aspect ratio
    set(gca, 'XTick', [], 'YTick', []); % Hide the ticks
    box off; % Hide the box around the plot
    title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
    % titleHandle.FontSize = 8; % Decrease font size

    % generate label for schmid_value used to order
    schmid_var_value = AllData{i}.(schmid_var)(1);
    if schmid_var_value < 1.0e+3
        formatted_value = num2str(schmid_var_value, '%.1e');
    else
        formatted_value = num2str(schmid_var_value);
    end
    schmid_var_txt = [(schmid_label)  formatted_value];
    xlabel(schmid_var_txt, 'FontSize', 8);
%--------------------------------------------------------------------------
    % Surfor polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_surf);
    rho = AllData{i}.rho_surf;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Surfor Distribution');
%--------------------------------------------------------------------------
    % Paror polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_par);
    rho = AllData{i}.rho_par;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Paror Distribution');
%--------------------------------------------------------------------------
    %  Sparor Shape Function
    nexttile
    shape_x = AllData{i}.cShape_x;
    shape_y = AllData{i}.cShape_y;
    
    % Plot shape function
    h = plot(shape_x, shape_y);
    % hold on

    % Format axes and data
    h.Color = color_plot;
    axis equal
    axis([-1 1 -1 1])
    plax = gca; plax.XTick = -1:1:1; plax.YTick = -1:1:1;
    
    % Add title and labels
    title('Shape Function');
    % xlabel(['proj. direction [' char(176) ']'])
    % ylabel('rel. projections length')
   %--------------------------------------------------------------------------
     % surfor projection direction plot
    nexttile
    proj_dir_s = AllData{i}.pAngle_surf(1:37);
    proj_length_s = AllData{i}.pLength_surf(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_s);
    [pks_min, locs_min] = findpeaks(-proj_length_s);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_s, proj_length_s);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_s(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_s(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Surfor Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
    % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------
    % Paror projection direction plot
    nexttile
    proj_dir_p = AllData{i}.pAngle_par(1:37);
    proj_length_p = AllData{i}.pLength_par(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_p);
    [pks_min, locs_min] = findpeaks(-proj_length_p);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_p, proj_length_p);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_p(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_p(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Paror Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
   % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------


end 

% Create an invisible axes for the colorbar
cbaxes = axes('Position',[.98 .33 .02 .575], 'Visible', 'off'); % Adjust these values as needed
% Create the colorbar in the invisible axes
colormap(cbaxes, colormap_custom); % Apply your custom colormap to the colorbar
c = colorbar(cbaxes, 'EastOutside'); % Create the colorbar
cbaxes.CLim = [min(schmid_data.(schmid_var)) max(schmid_data.(schmid_var))];
% Position the ticks on the left side of the colorbar
c.AxisLocation = 'in'; % Position the ticks inside the colorbar
ylabel(c, (schmid_label), 'Rotation', 90); % Add a title to the colorbar


% Export the final figure
fname = ['sparor_' schmid_var '_ordered.png'];
full_path = fullfile(pname_export, fname);
% print(gcf, '-dpng', '-r2000', full_path);
exportgraphics(gcf, full_path, 'Resolution', 1000);
fprintf([schmid_var ' saved successfully.'])


%% REORDER AllData based upon chosen variable

% Extract the 'score' from each dataset into an array




schmid_var = 'Temp' % change input for ordering data
schmid_label = "Temperature "; % change label for ordering variable


%set up the ordering function

% begin ordering datasets
order_var = cellfun(@(x) get_field_value(x, schmid_var), AllData);
% Get the indices of the sorted scores
[~, sortedIndices] = sort(order_var, 'ascend');
% Reorder AllData based on the sorted indices
AllData = AllData(sortedIndices);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% POLAR HISTOGRAM (Tiled Layout) - Distributions
%--------------------------------------------------------------------------
% Setup TiledLayout
%--------------------------------------------------------------------------
t = tiledlayout(6, 8);
t.TileSpacing = 'compact';
t.Padding = 'compact'; % Adjust the padding to create more space around the tiles
t.TileIndexing = 'columnmajor';
t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% t.Parent.OuterPosition = [200, 150, 1500, 800]; % workable size
set(t, 'DefaultLineLineWidth', 1.2);

% Set figure title with additional space
titleHandle = title(t, ['Surfor & Paror Orientation Distributions - ' schmid_label '(Schmid et al. 1987)']);
titleHandle.FontWeight = 'bold';
titleHandle.FontSize = 14;

% Adjusting the overall padding to create space for the title
t.Padding = 'tight'; % Set tight padding
t.TileSpacing = 'tight'; % Set tight tile spacing

 
%--------------------------------------------------------------------------
% FIGURE PLOTS 
%--------------------------------------------------------------------------
colormap_custom = i1_lut;

for i = 1:8
    
    %set up colormap
    var_row_cmap = round((AllData{i}.(schmid_var)(1,:))/max(schmid_data.(schmid_var))*256);
    color_CT = [0 0 0; colormap_custom(var_row_cmap,:)];
    color_plot = [colormap_custom(var_row_cmap,:)];
    
   % Image tile
    nexttile
    img = image(CT{i});
    % Manually adjust the color data of the image
    img.CData = ind2rgb(img.CData, color_CT);
    axis image % Preserve aspect ratio
    set(gca, 'XTick', [], 'YTick', []); % Hide the ticks
    box off; % Hide the box around the plot
    title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
    % titleHandle.FontSize = 8; % Decrease font size
% generate label for schmid_value used to order
    schmid_var_value = AllData{i}.(schmid_var)(1);
    % if schmid_var_value < 1.0e+3
    %     formatted_value = num2str(schmid_var_value, '%.1e');
    % else
    %     formatted_value = num2str(schmid_var_value);
    % end
    schmid_var_txt = [(schmid_label)  num2str(AllData{i}.(schmid_var)(1))];
    xlabel(schmid_var_txt, 'FontSize', 8);
%--------------------------------------------------------------------------
    % Surfor polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_surf);
    rho = AllData{i}.rho_surf;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Surfor Distribution');
%--------------------------------------------------------------------------
    % Paror polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_par);
    rho = AllData{i}.rho_par;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Paror Distribution');
%--------------------------------------------------------------------------
    %  Sparor Shape Function
    nexttile
    shape_x = AllData{i}.cShape_x;
    shape_y = AllData{i}.cShape_y;
    
    % Plot shape function
    h = plot(shape_x, shape_y);
    % hold on

    % Format axes and data
    h.Color = color_plot;
    axis equal
    axis([-1 1 -1 1])
    plax = gca; plax.XTick = -1:1:1; plax.YTick = -1:1:1;
    
    % Add title and labels
    title('Shape Function');
    % xlabel(['proj. direction [' char(176) ']'])
    % ylabel('rel. projections length')
   %--------------------------------------------------------------------------
     % surfor projection direction plot
    nexttile
    proj_dir_s = AllData{i}.pAngle_surf(1:37);
    proj_length_s = AllData{i}.pLength_surf(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_s);
    [pks_min, locs_min] = findpeaks(-proj_length_s);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_s, proj_length_s);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_s(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_s(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Surfor Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
    % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------
    % Paror projection direction plot
    nexttile
    proj_dir_p = AllData{i}.pAngle_par(1:37);
    proj_length_p = AllData{i}.pLength_par(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_p);
    [pks_min, locs_min] = findpeaks(-proj_length_p);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_p, proj_length_p);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_p(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_p(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Paror Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
   % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------

end

% Create an invisible axes for the colorbar
cbaxes = axes('Position',[.98 .33 .02 .575], 'Visible', 'off'); % Adjust these values as needed
% Create the colorbar in the invisible axes
colormap(cbaxes, colormap_custom); % Apply your custom colormap to the colorbar
c = colorbar(cbaxes, 'EastOutside'); % Create the colorbar
cbaxes.CLim = [min(schmid_data.(schmid_var)) max(schmid_data.(schmid_var))];
% Position the ticks on the left side of the colorbar
c.AxisLocation = 'in'; % Position the ticks inside the colorbar
ylabel(c, (schmid_label), 'Rotation', 90); % Add a title to the colorbar



% Export the final figure
fname = ['sparor_' schmid_var '_ordered.png'];
full_path = fullfile(pname_export, fname);
exportgraphics(gcf, full_path, 'Resolution', 1000);
fprintf([schmid_var ' saved successfully.'])



%% REORDER AllData based upon chosen variable

% Extract the 'score' from each dataset into an array




schmid_var = 'ThicknessShearZone' % change input for ordering data
schmid_label = "Shear Zone Thickness "; % change label for ordering variable


%set up the ordering function

% begin ordering datasets
order_var = cellfun(@(x) get_field_value(x, schmid_var), AllData);
% Get the indices of the sorted scores
[~, sortedIndices] = sort(order_var, 'ascend');
% Reorder AllData based on the sorted indices
AllData = AllData(sortedIndices);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% POLAR HISTOGRAM (Tiled Layout) - Distributions
%--------------------------------------------------------------------------
% Setup TiledLayout
%--------------------------------------------------------------------------
t = tiledlayout(6, 8);
t.TileSpacing = 'compact';
t.Padding = 'compact'; % Adjust the padding to create more space around the tiles
t.TileIndexing = 'columnmajor';
t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% t.Parent.OuterPosition = [200, 150, 1500, 800]; % workable size
set(t, 'DefaultLineLineWidth', 1.2);

% Set figure title with additional space
titleHandle = title(t, ['Surfor & Paror Orientation Distributions - ' schmid_label '(Schmid et al. 1987)']);
titleHandle.FontWeight = 'bold';
titleHandle.FontSize = 14;

% Adjusting the overall padding to create space for the title
t.Padding = 'tight'; % Set tight padding
t.TileSpacing = 'tight'; % Set tight tile spacing

 
%--------------------------------------------------------------------------
% FIGURE PLOTS 
%--------------------------------------------------------------------------
colormap_custom = i1_lut;

for i = 1:8
    
    %set up colormap
    var_row_cmap = round((AllData{i}.(schmid_var)(1,:))/max(schmid_data.(schmid_var))*256);
    color_CT = [0 0 0; colormap_custom(var_row_cmap,:)];
    color_plot = [colormap_custom(var_row_cmap,:)];
    
   % Image tile
    nexttile
    img = image(CT{i});
    % Manually adjust the color data of the image
    img.CData = ind2rgb(img.CData, color_CT);
    axis image % Preserve aspect ratio
    set(gca, 'XTick', [], 'YTick', []); % Hide the ticks
    box off; % Hide the box around the plot
    title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
    % titleHandle.FontSize = 8; % Decrease font size

    % generate label for schmid_value used to order
    schmid_var_value = AllData{i}.(schmid_var)(1);
    % if schmid_var_value < 1.0e+3
    %     formatted_value = num2str(schmid_var_value, '%.1e');
    % else
    %     formatted_value = num2str(schmid_var_value);
    % end
    schmid_var_txt = [(schmid_label)  num2str(AllData{i}.(schmid_var)(1))];
    xlabel(schmid_var_txt, 'FontSize', 8);
%--------------------------------------------------------------------------
    % Surfor polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_surf);
    rho = AllData{i}.rho_surf;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Surfor Distribution');
%--------------------------------------------------------------------------
    % Paror polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_par);
    rho = AllData{i}.rho_par;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Paror Distribution');
%--------------------------------------------------------------------------
    %  Sparor Shape Function
    nexttile
    shape_x = AllData{i}.cShape_x;
    shape_y = AllData{i}.cShape_y;
    
    % Plot shape function
    h = plot(shape_x, shape_y);
    % hold on

    % Format axes and data
    h.Color = color_plot;
    axis equal
    axis([-1 1 -1 1])
    plax = gca; plax.XTick = -1:1:1; plax.YTick = -1:1:1;
    
    % Add title and labels
    title('Shape Function');
    % xlabel(['proj. direction [' char(176) ']'])
    % ylabel('rel. projections length')
   %--------------------------------------------------------------------------
     % surfor projection direction plot
    nexttile
    proj_dir_s = AllData{i}.pAngle_surf(1:37);
    proj_length_s = AllData{i}.pLength_surf(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_s);
    [pks_min, locs_min] = findpeaks(-proj_length_s);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_s, proj_length_s);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_s(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_s(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Surfor Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
    % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------
    % Paror projection direction plot
    nexttile
    proj_dir_p = AllData{i}.pAngle_par(1:37);
    proj_length_p = AllData{i}.pLength_par(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_p);
    [pks_min, locs_min] = findpeaks(-proj_length_p);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_p, proj_length_p);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_p(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_p(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Paror Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
   % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------


end 

% Create an invisible axes for the colorbar
cbaxes = axes('Position',[.98 .33 .02 .575], 'Visible', 'off'); % Adjust these values as needed
% Create the colorbar in the invisible axes
colormap(cbaxes, colormap_custom); % Apply your custom colormap to the colorbar
c = colorbar(cbaxes, 'EastOutside'); % Create the colorbar
cbaxes.CLim = [min(schmid_data.(schmid_var)) max(schmid_data.(schmid_var))];
% Position the ticks on the left side of the colorbar
c.AxisLocation = 'in'; % Position the ticks inside the colorbar
ylabel(c, (schmid_label), 'Rotation', 90); % Add a title to the colorbar


% Export the final figure
fname = ['sparor_' schmid_var '_ordered.png'];
full_path = fullfile(pname_export, fname);
% print(gcf, '-dpng', '-r2000', full_path);
exportgraphics(gcf, full_path, 'Resolution', 1000);
fprintf([schmid_var ' saved successfully.'])

%% REORDER AllData based upon chosen variable

% Extract the 'score' from each dataset into an array

schmid_var = 'PermanentShear' % change input for ordering data
schmid_label = "Permanent Shear "; % change label for ordering variable


%set up the ordering function

% begin ordering datasets
order_var = cellfun(@(x) get_field_value(x, schmid_var), AllData);
% Get the indices of the sorted scores
[~, sortedIndices] = sort(order_var, 'ascend');
% Reorder AllData based on the sorted indices
AllData = AllData(sortedIndices);


%--------------------------------------------------------------------------
%--------------------------------------------------------------------------



% POLAR HISTOGRAM (Tiled Layout) - Distributions
%--------------------------------------------------------------------------
% Setup TiledLayout
%--------------------------------------------------------------------------
t = tiledlayout(6, 8);
t.TileSpacing = 'compact';
t.Padding = 'compact'; % Adjust the padding to create more space around the tiles
t.TileIndexing = 'columnmajor';
t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% t.Parent.OuterPosition = [200, 150, 1500, 800]; % workable size
set(t, 'DefaultLineLineWidth', 1.2);

% Set figure title with additional space
titleHandle = title(t, ['Surfor & Paror Orientation Distributions - ' schmid_label '(Schmid et al. 1987)']);
titleHandle.FontWeight = 'bold';
titleHandle.FontSize = 14;

% Adjusting the overall padding to create space for the title
t.Padding = 'tight'; % Set tight padding
t.TileSpacing = 'tight'; % Set tight tile spacing
 
%--------------------------------------------------------------------------
% FIGURE PLOTS 
%--------------------------------------------------------------------------
colormap_custom = i1_lut;

for i = 1:8
    
    %set up colormap
    var_row_cmap = round((AllData{i}.(schmid_var)(1,:))/max(schmid_data.(schmid_var))*256);
    color_CT = [0 0 0; colormap_custom(var_row_cmap,:)];
    color_plot = [colormap_custom(var_row_cmap,:)];
    
   % Image tile
    nexttile
    img = image(CT{i});
    % Manually adjust the color data of the image
    img.CData = ind2rgb(img.CData, color_CT);
    axis image % Preserve aspect ratio
    set(gca, 'XTick', [], 'YTick', []); % Hide the ticks
    box off; % Hide the box around the plot
    title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
    % titleHandle.FontSize = 8; % Decrease font size

    % generate label for schmid_value used to order
    schmid_var_value = AllData{i}.(schmid_var)(1);
    % if schmid_var_value < 1.0e+3
    %     formatted_value = num2str(schmid_var_value, '%.1e');
    % else
    %     formatted_value = num2str(schmid_var_value);
    % end
    schmid_var_txt = [(schmid_label)  num2str(AllData{i}.(schmid_var)(1))];
    xlabel(schmid_var_txt, 'FontSize', 8);
%--------------------------------------------------------------------------
    % Surfor polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_surf);
    rho = AllData{i}.rho_surf;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Surfor Distribution');
%--------------------------------------------------------------------------
    % Paror polar plot
    nexttile
    theta = deg2rad(AllData{i}.azi_par);
    rho = AllData{i}.rho_par;
    h = polarplot(theta, rho);
    h.Color = color_plot;
    pax = gca; % Get current polar axes
    pax.RTickLabel = {}; % Turn off rho labels
    pax.ThetaTick = 0:45:315; % Set theta ticks to every 45 degrees
    title('Paror Distribution');
%--------------------------------------------------------------------------
    %  Sparor Shape Function
    nexttile
    shape_x = AllData{i}.cShape_x;
    shape_y = AllData{i}.cShape_y;
    
    % Plot shape function
    h = plot(shape_x, shape_y);
    % hold on

    % Format axes and data
    h.Color = color_plot;
    axis equal
    axis([-1 1 -1 1])
    plax = gca; plax.XTick = -1:1:1; plax.YTick = -1:1:1;
    
    % Add title and labels
    title('Shape Function');
    % xlabel(['proj. direction [' char(176) ']'])
    % ylabel('rel. projections length')
   %--------------------------------------------------------------------------
     % surfor projection direction plot
    nexttile
    proj_dir_s = AllData{i}.pAngle_surf(1:37);
    proj_length_s = AllData{i}.pLength_surf(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_s);
    [pks_min, locs_min] = findpeaks(-proj_length_s);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_s, proj_length_s);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_s(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_s(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_s(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_s(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Surfor Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
    % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------
    % Paror projection direction plot
    nexttile
    proj_dir_p = AllData{i}.pAngle_par(1:37);
    proj_length_p = AllData{i}.pLength_par(1:37);
    % Find all local maxima
    [pks_max, locs_max] = findpeaks(proj_length_p);
    [pks_min, locs_min] = findpeaks(-proj_length_p);
    locs_min = locs_min(pks_min ~= 0); % Filter out the zero minima if any
    % If there are no maxima or minima, continue to the next iteration
    if isempty(locs_max) || isempty(locs_min)
        continue;
    end
    % Select random index for maxima and minima
    randMaxIndex = randi(length(locs_max));
    randMinIndex = randi(length(locs_min));
    % PLot PAROR
    h = plot(proj_dir_p, proj_length_p);
    hold on
    % Now use randMaxIndex and randMinIndex to plot the points
    scatter(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), 'k', 'filled','s');
    scatter(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), 'k', 'filled','s');
    % Label the y-value of the random maxima
    t_max = text(proj_dir_p(locs_max(randMaxIndex)), pks_max(randMaxIndex), ...
    ['Max. ' num2str(proj_dir_p(locs_max(randMaxIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_max.Position(2) = t_max.Position(2)-0.05;
    hold on
    % Label the y-value of the random minima
    t_min =  text(proj_dir_p(locs_min(randMinIndex)), -pks_min(randMinIndex), ...
    ['Min. ' num2str(proj_dir_p(locs_min(randMinIndex)))], ...
    'VerticalAlignment', 'top','HorizontalAlignment','center','FontSize',6);
    t_min.Position(2) = t_min.Position(2)-0.05;
    % Format axes and data
    h.Color = color_plot;
    axis([0 180 0 1])
    plax = gca; plax.XTick = 0:30:180; plax.YTick = 0:0.25:1 ;
    grid on; set(gca,'XGrid','on','YGrid','off');
    % Add title and labels
    title('Paror Orientations');
    xlabel(['proj. direction [' char(176) ']'])
    ylabel('rel. proj. length')
    % Calculate the difference between the y-values of the maxima and minima
   % Calculate the difference between the y-values of the maxima and minima
    diff = abs(proj_dir_s(locs_max(randMaxIndex)) - proj_dir_s(locs_min(randMinIndex)));
    % Annotate the plot based on the difference
    if diff == 90
        annotation = [num2str(diff) char(176) ' = orthorhombic'];
        text(135, 0.15, annotation, 'FontSize', 6);
    else
        annotation = [num2str(diff) char(176) ' = monoclinic'];
        text(140, 0.15, annotation, 'FontSize', 6);
    end
%--------------------------------------------------------------------------




end 

% Create an invisible axes for the colorbar
cbaxes = axes('Position',[.98 .33 .02 .575], 'Visible', 'off'); % Adjust these values as needed
% Create the colorbar in the invisible axes
colormap(cbaxes, colormap_custom); % Apply your custom colormap to the colorbar
c = colorbar(cbaxes, 'EastOutside'); % Create the colorbar
cbaxes.CLim = [min(schmid_data.(schmid_var)) max(schmid_data.(schmid_var))];
% Position the ticks on the left side of the colorbar
c.AxisLocation = 'in'; % Position the ticks inside the colorbar
ylabel(c, (schmid_label), 'Rotation', 90); % Add a title to the colorbar


% Export the final figure
fname = ['sparor_' schmid_var '_ordered.png'];
full_path = fullfile(pname_export, fname);
% print(gcf, '-dpng', '-r2000', full_path);
exportgraphics(gcf, full_path, 'Resolution', 1000);
fprintf([schmid_var ' saved successfully.'])



%% Test Workspace

% %%
% 
% % Extract the 'score' from each dataset into an array
% 
% schmid_var = 'ShearStress' % change input for ordering data
% schmid_label = 'Shear Stress '; % change label for ordering variable
% 
% 
% %set up the ordering function
% 
% % begin ordering datasets
% order_var = cellfun(@(x) get_field_value(x, schmid_var), AllData);
% % Get the indices of the sorted scores
% [~, sortedIndices] = sort(order_var, 'ascend');
% % Reorder AllData based on the sorted indices
% AllData = AllData(sortedIndices);
% 
%  t = tiledlayout(1, 8);
%  t.Parent.OuterPosition = [-1500, 50, 3000, 1000]; % final size
% 
% %--------------------------------------------------------------------------
% % FIGURE PLOTS 
% %--------------------------------------------------------------------------
% colormap_custom = i1_lut;
% 
% for i = 1:8
% 
%     %set up colormap
%     var_row_cmap = round((AllData{i}.(schmid_var)(1,:))/max(schmid_data.(schmid_var))*256);
%     color_CT = [0 0 0; colormap_custom(var_row_cmap,:)];
%     color_plot = [colormap_custom(var_row_cmap,:)];
% 
%     % Image tile
%     nexttile
%     img = image(CT{i});
%     % Manually adjust the color data of the image
%     img.CData = ind2rgb(img.CData, color_CT);
%     axis image % Preserve aspect ratio
%     set(gca, 'XTick', [], 'YTick', []); % Hide the ticks
%     box off; % Hide the box around the plot
%     title(['CT ' num2str(AllData{i}.SampleNo__Schmid_(1))]);
%     % titleHandle.FontSize = 8; % Decrease font size
% 
%     % generate label for schmid_value used to order
%     schmid_var_value = AllData{i}.(schmid_var)(1);
%     if schmid_var_value < 1.0e+3
%         formatted_value = num2str(schmid_var_value, '%.1e');
%     else
%         formatted_value = num2str(schmid_var_value);
%     end
%     schmid_var_txt = [(schmid_label)  num2str(AllData{i}.(schmid_var)(1))];
%     xlabel(schmid_var_txt, 'FontSize', 8);
% end
% 


%%
clc
fprintf('The script finished successfully. (2/2)')

toc
return


%% functions

function val = get_field_value(x, var)
    val = x.(var)(1);
end
